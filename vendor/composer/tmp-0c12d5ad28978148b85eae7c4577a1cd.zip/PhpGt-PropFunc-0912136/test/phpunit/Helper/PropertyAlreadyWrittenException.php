<?php
namespace Gt\PropFunc\Test\Helper;

use Gt\PropFunc\PropFuncException;

class PropertyAlreadyWrittenException extends PropFuncException {}
