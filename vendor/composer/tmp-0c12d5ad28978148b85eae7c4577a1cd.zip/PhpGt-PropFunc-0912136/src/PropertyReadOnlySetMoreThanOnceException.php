<?php
namespace Gt\PropFunc;

class PropertyReadOnlySetMoreThanOnceException extends PropertyReadOnlyException {}
