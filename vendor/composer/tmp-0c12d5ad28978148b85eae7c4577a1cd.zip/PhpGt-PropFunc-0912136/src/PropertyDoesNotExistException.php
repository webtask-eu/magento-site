<?php
namespace Gt\PropFunc;

class PropertyDoesNotExistException extends PropFuncException {}
