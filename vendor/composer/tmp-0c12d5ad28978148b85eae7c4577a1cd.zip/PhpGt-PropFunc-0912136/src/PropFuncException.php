<?php
namespace Gt\PropFunc;

use RuntimeException;

class PropFuncException extends RuntimeException {}
