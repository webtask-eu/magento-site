<?php
namespace Gt\PropFunc;

class PropertyReadOnlyException extends PropFuncException {}
