<?php
namespace Gt\Dom;

use DOMAttr;

class Attr extends DOMAttr {
	use RegisteredNodeClass;
}
