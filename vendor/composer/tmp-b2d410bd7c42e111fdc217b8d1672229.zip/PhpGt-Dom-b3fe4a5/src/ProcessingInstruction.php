<?php
namespace Gt\Dom;

use DOMProcessingInstruction;

class ProcessingInstruction extends DOMProcessingInstruction {
	use RegisteredNodeClass;
}
