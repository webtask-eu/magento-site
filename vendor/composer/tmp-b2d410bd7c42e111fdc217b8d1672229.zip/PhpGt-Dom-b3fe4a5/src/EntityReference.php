<?php
namespace Gt\Dom;

use DOMEntityReference;

class EntityReference extends DOMEntityReference {

}
