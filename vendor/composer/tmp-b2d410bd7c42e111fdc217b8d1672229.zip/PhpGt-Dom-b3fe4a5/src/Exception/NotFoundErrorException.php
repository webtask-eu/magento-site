<?php
namespace Gt\Dom\Exception;

class NotFoundErrorException extends DomException {}
