<?php
namespace Gt\Dom\Exception;

class HierarchyRequestError extends DomException {
}
