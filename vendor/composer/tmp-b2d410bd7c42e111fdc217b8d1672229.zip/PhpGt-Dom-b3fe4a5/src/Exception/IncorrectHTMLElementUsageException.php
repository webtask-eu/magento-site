<?php
namespace Gt\Dom\Exception;

class IncorrectHTMLElementUsageException extends DomException {

}
