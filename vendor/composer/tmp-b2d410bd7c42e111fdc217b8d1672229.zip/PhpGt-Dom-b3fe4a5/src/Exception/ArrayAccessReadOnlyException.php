<?php
namespace Gt\Dom\Exception;

class ArrayAccessReadOnlyException extends DomException {

}
