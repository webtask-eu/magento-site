<?php
namespace Gt\Dom\Exception;

class DocumentStreamIsClosedException extends DomException {}
