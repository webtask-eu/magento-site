<?php
namespace Gt\Dom\Exception;

class InvalidCharacterException extends NotSupportedException {}
