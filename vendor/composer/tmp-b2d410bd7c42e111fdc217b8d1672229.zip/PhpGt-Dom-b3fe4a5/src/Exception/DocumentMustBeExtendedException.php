<?php
namespace Gt\Dom\Exception;

class DocumentMustBeExtendedException extends DomException {}
