<?php
namespace Gt\Dom\Exception;

class ClientSideOnlyFunctionalityException extends DomException {}
