<?php
namespace Gt\Dom\Exception;

class EnumeratedValueException extends DomException {}
