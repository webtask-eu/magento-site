<?php
namespace Gt\Dom\Exception;

use RuntimeException;

class DomException extends RuntimeException {}
