<?php
namespace Gt\Dom\Exception;

class NotSupportedException extends DomException {}
