<?php
namespace Gt\Dom\Exception;

class WrongDocumentErrorException extends DomException {}
