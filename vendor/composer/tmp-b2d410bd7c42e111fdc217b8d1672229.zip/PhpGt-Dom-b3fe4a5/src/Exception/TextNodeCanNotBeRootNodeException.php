<?php
namespace Gt\Dom\Exception;

class TextNodeCanNotBeRootNodeException extends DomException {}
