<?php
namespace Gt\Dom\Exception;

class DocumentStreamSeekFailureException extends DomException {}
