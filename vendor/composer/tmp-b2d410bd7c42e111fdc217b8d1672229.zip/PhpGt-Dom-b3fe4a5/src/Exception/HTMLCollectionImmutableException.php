<?php
namespace Gt\Dom\Exception;

class HTMLCollectionImmutableException extends DomException {}
