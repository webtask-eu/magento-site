<?php
namespace Gt\Dom\Exception;

class DocumentStreamNotWritableException extends DomException {}
