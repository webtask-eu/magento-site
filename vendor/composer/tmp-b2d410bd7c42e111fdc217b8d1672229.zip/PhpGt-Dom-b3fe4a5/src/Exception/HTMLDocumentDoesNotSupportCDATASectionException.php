<?php
namespace Gt\Dom\Exception;

class HTMLDocumentDoesNotSupportCDATASectionException extends NotSupportedException {}
