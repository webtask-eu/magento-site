<?php
namespace Gt\Dom\Exception;

class DocumentHasMoreThanOneElementChildException extends DomException {}
