<?php
namespace Gt\Dom\Exception;

class XPathQueryException extends DomException {}
