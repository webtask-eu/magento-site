<?php
namespace Gt\Dom\Exception;

class NodeListImmutableException extends DomException {}
