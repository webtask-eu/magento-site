<?php
namespace Gt\Dom\Exception;

class IndexSizeException extends DomException {}
