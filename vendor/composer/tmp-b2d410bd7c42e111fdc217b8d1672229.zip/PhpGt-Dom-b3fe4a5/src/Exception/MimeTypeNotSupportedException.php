<?php
namespace Gt\Dom\Exception;

class MimeTypeNotSupportedException extends DomException {}
