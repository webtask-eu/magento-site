<?php
namespace Gt\Dom\Exception;

class WriteOnNonHTMLDocumentException extends DomException {}
