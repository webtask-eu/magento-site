<?php
namespace Gt\Dom\Exception;

class InvalidAdjacentPositionException extends DomException {}
