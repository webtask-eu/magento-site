<?php
namespace Gt\Dom;

class HTMLFormControlsCollection extends HTMLCollection {

}
