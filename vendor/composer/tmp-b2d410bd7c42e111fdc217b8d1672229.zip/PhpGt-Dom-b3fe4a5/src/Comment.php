<?php
namespace Gt\Dom;

use DOMComment;

class Comment extends DOMComment {
	use RegisteredNodeClass;
}
