<?php
namespace Gt\Dom;

use DOMDocumentType;

class DocumentType extends DOMDocumentType {
	use RegisteredNodeClass;
}
