<?php
namespace Gt\Dom;

class HTMLOptionsCollection extends HTMLCollection {
}
