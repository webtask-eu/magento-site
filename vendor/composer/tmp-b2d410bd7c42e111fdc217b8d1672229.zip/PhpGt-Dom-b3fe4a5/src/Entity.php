<?php
namespace Gt\Dom;

use DOMEntity;

class Entity extends DOMEntity {

}
