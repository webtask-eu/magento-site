<?php
namespace Gt\Dom;

use DOMNotation;

class Notation extends DOMNotation {

}
