<?php
namespace Gt\Dom;

use DOMCharacterData;

class CharacterData extends DOMCharacterData {

}
