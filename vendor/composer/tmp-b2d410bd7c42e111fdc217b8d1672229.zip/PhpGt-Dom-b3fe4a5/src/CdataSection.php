<?php
namespace Gt\Dom;

use DOMCdataSection;

class CdataSection extends DOMCdataSection {
	use RegisteredNodeClass;
}
