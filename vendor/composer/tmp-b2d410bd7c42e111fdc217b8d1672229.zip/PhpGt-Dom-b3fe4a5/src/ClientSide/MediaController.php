<?php
namespace Gt\Dom\ClientSide;

class MediaController extends ClientSideOnly {

}
