<?php
namespace Gt\Dom\ClientSide;

class TextTrack extends ClientSideOnly {

}
