<?php
namespace Gt\Dom\ClientSide;

class CSSStyleDeclaration extends ClientSideOnly {

}
