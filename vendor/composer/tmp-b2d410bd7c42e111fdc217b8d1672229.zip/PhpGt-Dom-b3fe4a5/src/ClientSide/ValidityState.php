<?php
namespace Gt\Dom\ClientSide;

class ValidityState extends ClientSideOnly {

}
