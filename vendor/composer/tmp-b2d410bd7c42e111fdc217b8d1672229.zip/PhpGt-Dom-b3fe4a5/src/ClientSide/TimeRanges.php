<?php
namespace Gt\Dom\ClientSide;

class TimeRanges extends ClientSideOnly {

}
