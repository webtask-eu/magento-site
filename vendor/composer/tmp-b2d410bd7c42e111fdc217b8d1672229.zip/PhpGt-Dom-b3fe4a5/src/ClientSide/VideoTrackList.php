<?php
namespace Gt\Dom\ClientSide;

class VideoTrackList extends ClientSideOnly {

}
