<?php
namespace Gt\Dom\ClientSide;

class AudioTrackList extends ClientSideOnly {

}
