<?php
namespace Gt\Dom\ClientSide;

class FileList extends ClientSideOnly {}
