<?php
namespace Gt\Dom\ClientSide;

class MediaStream extends ClientSideOnly {

}
