<?php
namespace Gt\Dom\ClientSide;

class TextTrackList extends ClientSideOnly {

}
