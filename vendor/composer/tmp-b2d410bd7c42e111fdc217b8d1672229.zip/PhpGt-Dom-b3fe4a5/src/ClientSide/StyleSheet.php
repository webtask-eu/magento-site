<?php
namespace Gt\Dom\ClientSide;

class StyleSheet extends ClientSideOnly {

}
