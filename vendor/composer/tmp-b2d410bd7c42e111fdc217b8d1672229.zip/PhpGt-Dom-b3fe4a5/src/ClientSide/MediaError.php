<?php
namespace Gt\Dom\ClientSide;

class MediaError extends ClientSideOnly {

}
