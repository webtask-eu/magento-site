# Magento 2 Functional Tests

The Functional Tests Module for **Magento_ConfigurableProduct** and **Magento_Wishlist** Modules.
