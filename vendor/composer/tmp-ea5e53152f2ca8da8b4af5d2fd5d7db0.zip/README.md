# Magento_DataExporter module

## Release notes

*Magento_DataExporter* module
