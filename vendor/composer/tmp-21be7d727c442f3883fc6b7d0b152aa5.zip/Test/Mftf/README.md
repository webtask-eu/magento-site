# Instant Purchase Functional Tests

The Functional Test Module for **Magento Instant Purchase** module.
