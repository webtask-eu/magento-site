<?php
/**
 *
 * Copyright © Magento, Inc. All rights reserved.
 * See COPYING.txt for license details.
 */
namespace Magento\Bundle\Controller\Adminhtml\Bundle\Product\Edit;

class GridOnly extends \Magento\Catalog\Controller\Adminhtml\Product\GridOnly
{
}
