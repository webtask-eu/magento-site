<?php

namespace Facebook\WebDriver\Exception;

/**
 * @deprecated Use Facebook\WebDriver\Exception\ElementNotInteractableException
 */
class ElementNotSelectableException extends ElementNotInteractableException
{
}
