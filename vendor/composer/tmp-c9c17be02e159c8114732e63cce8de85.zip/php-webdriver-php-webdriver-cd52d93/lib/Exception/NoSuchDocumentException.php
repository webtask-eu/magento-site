<?php

namespace Facebook\WebDriver\Exception;

/**
 * @deprecated Use Facebook\WebDriver\Exception\NoSuchWindowException
 */
class NoSuchDocumentException extends NoSuchWindowException
{
}
