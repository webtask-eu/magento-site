
## Release notes

*Magento_DataExporter* module
