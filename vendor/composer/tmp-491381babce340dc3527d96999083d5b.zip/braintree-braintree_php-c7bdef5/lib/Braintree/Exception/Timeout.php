<?php

namespace Braintree\Exception;

use Braintree\Exception;

/**
 * Raised when a Timeout occurs
 */
class Timeout extends Exception
{
}
