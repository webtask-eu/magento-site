Module Magento\PayPal implements integration with the PayPal payment system. Namely, it enables the following payment methods:

* PayPal Express Checkout
* PayPal Payments Standard
* PayPal Payments Pro
* PayPal Credit
* PayFlow Payment Gateway
